def greet(name: str) -> str:
    return f"Hello, {name}! Welcome to MLOps."

def square(number: int) -> int:
    return number * number
